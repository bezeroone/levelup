console.log('꿈키움 도서관 홈페이지에 오신 것을 환영합니다!');

// Add simple hover interactions logic if needed in future
document.querySelectorAll('.menu-card').forEach(card => {
    card.addEventListener('mouseenter', () => {
        // Optional JS effects
    });
});
